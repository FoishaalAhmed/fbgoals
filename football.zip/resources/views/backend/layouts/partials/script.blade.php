<!-- Vendor js -->
<script src="{{ asset('public/assets/backend/js/vendor.min.js') }}"></script>

<!-- App js -->
<script src="{{ asset('public/assets/backend/js/app.min.js') }}"></script>

<!-- Plugins js-->
<script src="{{ asset('public/assets/backend/libs/flatpickr/flatpickr.min.js') }}"></script>
<script src="{{ asset('public/assets/backend/libs/apexcharts/apexcharts.min.js') }}"></script>
<script src="{{ asset('public/assets/backend/libs/selectize/js/standalone/selectize.min.js') }}"></script>

<!-- Main js -->
<script src="{{ asset('public/assets/backend/js/main.js') }}"></script>

@section('js')
    
@show