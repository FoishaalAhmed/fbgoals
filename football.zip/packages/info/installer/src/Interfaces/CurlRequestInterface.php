<?php 
namespace Info\Installer\Interfaces;

interface CurlRequestInterface {
	public function send($data);
}