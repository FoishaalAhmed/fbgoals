<!-- ========== Menu ========== -->
<div class="app-menu">

    <!-- Brand Logo -->
    <div class="logo-box">
        <!-- Brand Logo Light -->
        <a href="<?php echo e(url('/')); ?>" class="logo-light">
            <img src="<?php echo e(asset(lightLogo())); ?>" alt="logo" class="logo-lg">
            <img src="<?php echo e(asset(smallLogo())); ?>" alt="small logo" class="logo-sm">
        </a>

        <!-- Brand Logo Dark -->
        <a href="<?php echo e(url('/')); ?>" class="logo-dark">
            <img src="<?php echo e(asset(darkLogo())); ?>" alt="dark logo" class="logo-lg">
            <img src="<?php echo e(asset(smallLogo())); ?>" alt="small logo" class="logo-sm">
        </a>
    </div>

    <!-- menu-left -->
    <div class="scrollbar">

        <!--- Menu -->
        <ul class="menu">

            <li class="menu-title"><?php echo e(__('Navigation')); ?></li>

            <li class="menu-item">
                <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                    <span class="menu-icon"><i class="mdi mdi-view-dashboard-outline"></i></span>
                    <span class="menu-text"> <?php echo e(__('Dashboard')); ?> </span>
                </a>
            </li>

            <li class="menu-title"><?php echo e(__('Web')); ?></li>

            <?php if(auth()->user()->hasRole('Admin')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Matches')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/matches') || request()->is('admin/matches/*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.matches.index')); ?>" class="menu-link <?php echo e(request()->is('admin/matches') || request()->is('admin/matches/*') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-aperture"></i></span>
                            <span class="menu-text"> <?php echo e(__('Matches')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Feature Match')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/featured-matches') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.featured.matches.edit')); ?>" class="menu-link <?php echo e(request()->is('admin/featured-matches') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-aperture"></i></span>
                            <span class="menu-text"> <?php echo e(__('Featured Match')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('News')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/news') || request()->is('admin/news/*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.news.index')); ?>" class="menu-link <?php echo e(request()->is('admin/news') || request()->is('admin/news/*') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-send"></i></span>
                            <span class="menu-text"> <?php echo e(__('News')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Video')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/videos') || request()->is('admin/videos/*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.videos.index')); ?>" class="menu-link <?php echo e(request()->is('admin/videos') || request()->is('admin/videos/*') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-video"></i></span>
                            <span class="menu-text"> <?php echo e(__('Videos')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('League')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/leagues') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.leagues.edit')); ?>" class="menu-link <?php echo e(request()->is('admin/leagues') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-globe"></i></span>
                            <span class="menu-text"> <?php echo e(__('Leagues')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Season')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/seasons') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.seasons.edit')); ?>" class="menu-link <?php echo e(request()->is('admin/seasons') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-calendar"></i></span>
                            <span class="menu-text"> <?php echo e(__('Seasons')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Team')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/teams') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.teams.edit')); ?>" class="menu-link <?php echo e(request()->is('admin/teams') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-user-plus"></i></span>
                            <span class="menu-text"> <?php echo e(__('Teams')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Social')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/social') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.socials.edit')); ?>" class="menu-link <?php echo e(request()->is('admin/social') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-rss"></i></span>
                            <span class="menu-text"> <?php echo e(__('Socials')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Page')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/pages') || request()->is('admin/pages/*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.pages.index')); ?>" class="menu-link <?php echo e(request()->is('admin/pages') || request()->is('admin/pages/*') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-map"></i></span>
                            <span class="menu-text"> <?php echo e(__('Pages')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Setting')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/settings') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.settings.create')); ?>" class="menu-link <?php echo e(request()->is('admin/settings') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-settings "></i></span>
                            <span class="menu-text"> <?php echo e(__('Settings')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User')): ?>
                    <li class="menu-item <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'menuitem-active' : ''); ?>">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="menu-link <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : ''); ?>">
                            <span class="menu-icon"><i class="fe-users"></i></span>
                            <span class="menu-text"> <?php echo e(__('Users')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
        <!--- End Menu -->
        <div class="clearfix"></div>
    </div>
</div>
<!-- ========== Left menu End ========== -->
<?php /**PATH C:\wamp64\www\football\resources\views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>