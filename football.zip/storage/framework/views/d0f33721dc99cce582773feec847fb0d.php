<!-- Vendor js -->
<script src="<?php echo e(asset('public/assets/backend/js/vendor.min.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('public/assets/backend/js/app.min.js')); ?>"></script>

<!-- Plugins js-->
<script src="<?php echo e(asset('public/assets/backend/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/backend/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/backend/libs/selectize/js/standalone/selectize.min.js')); ?>"></script>

<!-- Main js -->
<script src="<?php echo e(asset('public/assets/backend/js/main.js')); ?>"></script>

<?php $__env->startSection('js'); ?>
    
<?php echo $__env->yieldSection(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/layouts/partials/script.blade.php ENDPATH**/ ?>