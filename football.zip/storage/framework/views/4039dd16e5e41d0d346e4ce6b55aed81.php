<?php $__env->startSection('title', __('Football Scores and Fixtures - :x', ['x' => settings('name')])); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/fixture.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--Main Content Start-->
    <div class="main-content wf100">

        <!--Sports Widgets Start-->
        <section class="wf100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-12">
                        <div id="carouselExampleControls" class="carousel slide" data-interval="false">
                            <div class="carousel-inner">
                                <div class="carousel-item">
                                    <div class="carousel-caption">
                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-31 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-31 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-30 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-30 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-29 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-29 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-28 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-28 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-27 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-27 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-26 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-26 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-25 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-25 days'))); ?></a></span>

                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-24 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-24 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-23 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-23 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-22 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-22 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-21 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-21 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-20 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-20 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-19 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-19 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-18 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-18 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">
                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-17 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-17 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-16 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-16 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-15 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-15 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-14 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-14 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-13 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-13 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-12 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-12 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-11 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-11 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">
                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-10 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-10 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-9 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-9 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-8 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-8 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-7 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-7 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-6 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-6 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-5 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-5 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-4 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-4 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item active">
                                    <div class="carousel-caption">
                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-3 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-3 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-2 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-2 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '-1 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '-1 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                style="color: <?php echo e($date == date('Y-m-d', strtotime($date)) ? '#07f585' : ''); ?>"
                                                href="<?php echo e(route('fixtures', ['date' => $date])); ?>"><?php echo e(date('d/M', strtotime($date))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+1 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+1 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+2 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+2 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+3 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+3 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+4 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+4 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+5 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+5 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+6 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+6 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+7 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+7 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+8 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+8 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+9 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+9 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+10 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+10 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+11 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+11 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+12 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+12 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+13 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+13 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+14 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+14 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+15 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+15 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+16 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+16 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+17 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+17 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+18 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+18 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+19 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+19 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+20 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+20 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+21 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+21 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+22 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+22 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+23 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+23 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+24 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+24 days'))); ?></a></span>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-caption">

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+25 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+25 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+26 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+26 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+27 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+27 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+28 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+28 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+29 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+29 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+30 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+30 days'))); ?></a></span>

                                        <span class="date-design"><a
                                                href="<?php echo e(route('fixtures', ['date' => date('Y-m-d', strtotime($date . '+31 days'))])); ?>"><?php echo e(date('d/M', strtotime($date . '+31 days'))); ?></a></span>
                                    </div>
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button"
                                data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only"><?php echo e(__('Previous')); ?></span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleControls" role="button"
                                data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only"><?php echo e(__('Next')); ?></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php
                        $statusArray = ['TBD', 'NS', 'PST', 'CANC', 'ABD', 'AWD', 'WO'];
                        $liveStatus = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'INT', 'LIVE'];
                    ?>

                    <div class="col-lg-8 col-md-8 col-12">

                        <div class="accordion" id="accordionExample">
                            <?php if($fixtures): ?>
                                <?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item">

                                        <div class="item-header" id="<?= $key ?>">
                                            <h2 class="mb-20">
                                                <button class="btn btn-link" type="button" data-toggle="collapse"
                                                    data-target="#collapseOne<?= $key ?>" aria-expanded="true"
                                                    aria-controls="collapseOne<?= $key ?>">
                                                    <?php echo e($value['league']); ?>

                                                    <i class="fe-chevron-down"></i>
                                                </button>
                                            </h2>
                                        </div>

                                        <div id="collapseOne<?= $key ?>"
                                            class="collapse <?php echo e(in_array($value['leagueid'], $fixedLeagues) ? 'show' : ''); ?>"
                                            aria-labelledby="headingOne<?= $key ?>" data-parent="#accordionExample">
                                            <?php $__currentLoopData = $value['matches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="last-match-result-full-light"
                                                    onclick="redirectToURL('<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>')">
                                                    <div class="row">
                                                        <div class="col-5 no-padding">
                                                            <div class="match-left">
                                                                <div class="mtl-left"> <img
                                                                        src="<?php echo e($match['homeTeamLogo']); ?>" alt="">
                                                                    <strong><a class="color-bcc9ea"
                                                                            href="<?php echo e(route('teams.matches', [$match['homeTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['homeTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['homeTeamName']); ?></a></strong>
                                                                </div>
                                                                <?php if(!in_array($match['shortStatus'], $statusArray)): ?>
                                                                    <div class="mscore float-right">
                                                                        <strong><?php echo e($match['homeTeamGoal']); ?></strong>
                                                                    </div>
                                                                <?php endif; ?>

                                                            </div>
                                                        </div>
                                                        <div class="col-2 no-padding">
                                                            <div class="lmr-info">
                                                                <?php if($match['shortStatus'] === 'NS'): ?>
                                                                    <strong class="color-14844d">
                                                                        <?php echo e(date('d/m  h:i A', $match['date'])); ?> </strong>
                                                                <?php endif; ?>
                                                                <?php if(in_array($match['shortStatus'], $liveStatus)): ?>
                                                                    <strong
                                                                        class="color-6ed950-font-15"><?php echo e($match['elapsed'] . '"'); ?></strong>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>"
                                                                    class="mh"><?php echo e(in_array($match['fixtureId'], $matchArray) && in_array($match['shortStatus'], $liveStatus) ? __('Watch Live') : $match['longStatus']); ?></a>
                                                            </div>
                                                        </div>
                                                        <div class="col-5 no-padding">
                                                            <div class="match-right">
                                                                <?php if(!in_array($match['shortStatus'], $statusArray)): ?>
                                                                <div class="mscore">
                                                                    <strong><?php echo e($match['awayTeamGoal']); ?></strong>
                                                                </div>
                                                                <?php endif; ?>
                                                                <div class="mtl-right"> <img
                                                                        src="<?php echo e($match['awayTeamLogo']); ?>" alt="">
                                                                    <strong><a class="color-bcc9ea"
                                                                            href="<?php echo e(route('teams.matches', [$match['awayTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['awayTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['awayTeamName']); ?></a></strong>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>

                    </div>

                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="sidebar">
                            <!--widget start-->
                            <?php echo $__env->make('front.upcomingMatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--widget end-->
                            <!--widget start-->
                            <div class="h3-section-title"> <strong><?php echo e(__('Trending News')); ?></strong></div>
                            <div class="trending-news">
                                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--Expand-->
                                    <div class="list-box-expand <?= $key == 0 ? 'active' : '' ?>">
                                        <div class="news-caption">
                                            <div class="news-txt">
                                                <h4><a
                                                        href="<?php echo e(route('news.detail', [$item->id, str_replace([' ', '_', '&'], '-', strtolower($item->title))])); ?>"><?php echo e($item->title); ?></a>
                                                </h4>
                                                <ul class="news-meta">
                                                    <li><i class="fe-calendar"></i>
                                                        <?php echo e(date('D M, Y', strtotime($item->date))); ?></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="expand-news-img"><img
                                                src="<?php echo e(file_exists($item->photo) ? asset($item->photo) : asset('public/images/news.jpg')); ?>"
                                                alt=""></div>
                                    </div>
                                    <!--Expand-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <!--widget end-->
                            <!--widget start-->
                            <div class="widget">
                                <h4>Featured Videos</h4>
                                <div class="featured-video-widget">
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="fvideo-box mb15">
                                            <div class="fvid-cap">
                                                <div class="fvid-right">
                                                    <h5><a href="https://www.youtube.com/watch?v=<?= $item->link ?>"
                                                            target="_blank"><?php echo e($item->title); ?></a></h5>
                                                    <span><i class="fe-clock"></i>
                                                        <?php echo e(date('d M, Y', strtotime($item->date))); ?> </span>
                                                </div>
                                            </div>
                                            <img src="https://img.youtube.com/vi/<?= $item->link ?>/1.jpg" alt="">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <!--widget end-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Sports Widgets End-->
    </div>
    <!--Main Content End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/front/fixture.blade.php ENDPATH**/ ?>