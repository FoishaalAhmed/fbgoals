

<?php $__env->startSection('title', __('Installation Complete')); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="col-md-8 col-lg-6 col-xl-6">
        <div class="card bg-pattern">
            <div class="card-body p-4">
                <div class="text-center w-75 m-auto">
                    <p class="fw-bold mt-3"><?php echo e(__('Installation Complete')); ?></p>
                    <p class="text-muted mb-4"><?php echo e(__('Your application has been successfully installed!')); ?></p>
                </div>
                <div class="text-center d-grid">
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary waves-effect waves-light"> <?php echo e(__('Login')); ?> </a>
                </div>
            </div> <!-- end card-body -->
        </div>
        <!-- end card -->
    </div> <!-- end col -->
<?php $__env->stopSection(); ?>

            
<?php echo $__env->make('vendor.installer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/vendor/installer/finish.blade.php ENDPATH**/ ?>