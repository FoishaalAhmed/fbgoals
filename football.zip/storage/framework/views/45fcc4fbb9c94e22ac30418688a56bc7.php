<?php $__env->startSection('title', "$title"); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/matchdetail.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--Main Content Start-->
    <?php
        $statusArray = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'INT', 'LIVE'];
    ?>
    <div class="main-content wf100">
        <!--Sports Widgets Start-->
        <section class="wf100 p80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-12">
                        <div class="row">
                            <div class="col-12">
                                <!--Next Match Widget Start-->
                                <!--Box Start-->
                                <div class="group-result">
                                    <div class="nms-title">
                                        <h4><?php echo e(__('Match Detail')); ?></h4>
                                    </div>
                                    <div class="last-match-result-full-light">
                                        <div class="row">
                                            <div class="col-4 no-padding">
                                                <div class="match-left">
                                                    <div class="mtl-left"> <img src="<?php echo e($match[0]->teams->home->logo); ?>"
                                                            >
                                                        <strong><?php echo e($match[0]->teams->home->name); ?></strong>
                                                    </div>
                                                    <div class="mscore"> <strong><?php echo e($match[0]->goals->home); ?></strong></div>

                                                </div>
                                            </div>
                                            <div class="col-4 no-padding">
                                                <div class="lmr-info">
                                                    <strong><?php echo e($match[0]->league->name . ', ' . $match[0]->league->country); ?></strong>


                                                    <?php if(in_array($match[0]->fixture->status->short, $statusArray)): ?>
                                                        <strong class="color-6ed950-font-20"><?php echo e($match[0]->fixture->status->elapsed . '"'); ?></strong>
                                                    <?php else: ?>
                                                        <strong class="color-007399-font-20"><?php echo e($match[0]->fixture->status->long); ?></strong>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                            <div class="col-4 no-padding">
                                                <div class="match-right">
                                                    <div class="mscore"> <strong><?php echo e($match[0]->goals->away); ?></strong></div>
                                                    <div class="mtl-right"> <img src="<?php echo e($match[0]->teams->away->logo); ?>"
                                                            >
                                                        <strong><?php echo e($match[0]->teams->away->name); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-3 no-padding"></div>
                                            <div class="col-md-6 no-padding">
                                                <?php
                                                    $finishDiff = (time() - strtotime($match[0]->fixture->date)) / 60;
                                                    $timeDiff = (strtotime($match[0]->fixture->date) - time())/60;
                                                ?>
                                                <?php if(isset($links)): ?>
                                                    <div class="row">
                                                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-lg-3 col-md-3 col-12 no-padding">
                                                                <?php if((in_array($match[0]->fixture->status->short, $statusArray) || $timeDiff < 30) && ($finishDiff < 120)): ?>
                                                                    <a class="nav-item nav-link live-link no-padding"
                                                                        href="javascript:;"
                                                                        onclick="window.open('<?= $link->link ?>', 'name','width=800,height=650')"><?php echo e(__('Stream')); ?>

                                                                        <?php echo e($loop->index + 1); ?></a>
                                                                <?php else: ?>
                                                                    <a class="nav-item nav-link live-link no-padding"
                                                                        href="javascript:;" data-toggle="modal"
                                                                        data-target="#myModal"><?php echo e(__('Stream')); ?>

                                                                        <?php echo e($loop->index + 1); ?></a>
                                                                <?php endif; ?>

                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-3 no-padding"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        

                        <div class="row">
                            <div class="col-12">
                                <nav>
                                    <div class="nav" id="nav-tab" role="tablist">

                                        <a class="nav-item nav-link nav-active active" id="nav-1-tab" data-toggle="tab"
                                            href="#nav-defenders" role="tab" aria-controls="nav-defenders"
                                            aria-selected="true"><?php echo e(__('Match Detail')); ?></a>

                                        <a class="nav-item nav-link nav-active" id="nav-2-tab" data-toggle="tab"
                                            href="#nav-gk" role="tab" aria-controls="nav-gk"
                                            aria-selected="false"><?php echo e(__('Line Up')); ?></a>

                                        <a class="nav-item nav-link nav-active " id="nav-3-tab" data-toggle="tab"
                                            href="#nav-forwarders" role="tab" aria-controls="nav-forwarders"
                                            aria-selected="false"><?php echo e(__('Head To Head')); ?></a>

                                        <a class="nav-item nav-link nav-active " id="nav-6-tab" data-toggle="tab"
                                            href="#nav-statistics" role="tab" aria-controls="nav-statistics"
                                            aria-selected="false"><?php echo e(__('Statistics')); ?></a>

                                        <a class="nav-item nav-link nav-active " id="nav-7-tab" data-toggle="tab"
                                            href="#nav-team" role="tab" aria-controls="nav-team"
                                            aria-selected="false"><?php echo e(__('Team')); ?></a>

                                    </div>
                                </nav>
                            </div>
                        </div>
                        <?php
                            if ($match[0]->lineups) {
                                if ($match[0]->teams->home->name == $match[0]->lineups[0]->team->name) {
                                    $homeFormation = $match[0]->lineups[0]->formation;
                                    $homeStartXI = $match[0]->lineups[0]->startXI;
                                    $homeSubstitutes = $match[0]->lineups[0]->substitutes;
                                    $homeCoach = $match[0]->lineups[0]->coach;
                                    $awayFormation = $match[0]->lineups[1]->formation;
                                    $awayStartXI = $match[0]->lineups[1]->startXI;
                                    $awaySubstitutes = $match[0]->lineups[1]->substitutes;
                                    $awayCoach = $match[0]->lineups[1]->coach;
                                } else {
                                    $homeFormation = $match[0]->lineups[1]->formation;
                                    $homeStartXI = $match[0]->lineups[1]->startXI;
                                    $homeSubstitutes = $match[0]->lineups[1]->substitutes;
                                    $homeCoach = $match[0]->lineups[1]->coach;
                                    $awayFormation = $match[0]->lineups[0]->formation;
                                    $awayStartXI = $match[0]->lineups[0]->startXI;
                                    $awaySubstitutes = $match[0]->lineups[0]->substitutes;
                                    $awayCoach = $match[0]->lineups[0]->coach;
                                }
                            }
                            
                            $images = [
                                'Card' => [
                                    'Red Card' => 'public/front/images/red-card.png',
                                    'Yellow Card' => 'public/front/images/yellow-card.png',
                                ],
                                'Goal' => 'public/front/images/slide1-football.png',
                                'subst' => 'public/front/images/substitution.png',
                                'Var' => 'public/front/images/var.png',
                            ];
                        ?>
                        <div class="col-12">
                            <div class="tab-content wf100" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-defenders" role="tabpanel"
                                    aria-labelledby="nav-1-tab">
                                     <?php if($match[0]->events): ?>
                                    <div class="container">
                                        <div class="timeline">
                                           
                                                <?php $__currentLoopData = $match[0]->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        switch ($event->type) {
                                                            case 'Card':
                                                                $image = $images[$event->type][$event->detail];
                                                                break;
                                                        
                                                            default:
                                                                $image = $images[$event->type];
                                                                break;
                                                        }
                                                        
                                                        switch ($event->type) {
                                                            case 'subst':
                                                                $player = $event->player->name . ' <-> ' . $event->assist->name;
                                                                break;
                                                        
                                                            default:
                                                                $player = $event->player->name;
                                                                break;
                                                        }
                                                    ?>
                                                    <div
                                                        class="row no-gutters justify-content-end justify-content-md-around align-items-start  timeline-nodes">
                                                        <div class="col-10 col-md-5 order-3 order-md-1 timeline-content">
                                                            <h3 class="text-light"><?php echo $player; ?>

                                                                <?php echo e($event->type); ?> <img src="<?php echo e(asset($image)); ?>" class="width-30"></h3>
                                                        </div>
                                                        <div
                                                            class="col-2 col-sm-1 px-md-3 order-2 timeline-image text-md-center">
                                                            <img src="" class="img-fluid"
                                                                alt='<?php echo e($event->time->elapsed); ?>"'>
                                                        </div>
                                                        <div class="col-10 col-md-5 order-1 order-md-3 py-3 timeline-date">
                                                            <time></time>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="nav-gk" role="tabpanel" aria-labelledby="nav-2-tab">
                                    <?php if($match[0]->lineups): ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="link-section">
                                                    <div class="row">
                                                        <div class="col-md-9">
                                                            <strong class="color-aliceblue"
                                                                ><?php echo e($match[0]->teams->home->name); ?>

                                                                <br />
                                                                <?php echo e(__('Formation')); ?> : <?php echo e($homeFormation); ?> </strong>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <img src="<?php echo e($match[0]->teams->home->logo); ?>" 
                                                                class="float-end width-50-float-right">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="point-table-widget bb-none">
                                                    <table>
                                                        <thead class="background-343e60">
                                                            <tr>
                                                                <th colspan="2"><?php echo e(__('Coach')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td></td>
                                                                <td>
                                                                    <?php echo e($homeCoach->name); ?>

                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="point-table-widget bb-bt-none">
                                                    <table>
                                                        <thead class="background-343e60">
                                                            <tr>
                                                                <th colspan="2"><?php echo e(__('Starting XI')); ?></th>
                                                                <th><?php echo e(__('Jersey')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php if($match[0]->lineups): ?>
                                                                <?php $__currentLoopData = $homeStartXI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><img src="<?php echo e(asset('public/images/player.jpg')); ?>" class="rounded width-50"></td>
                                                                        <td><strong><?php echo e($player->player->name); ?></strong>
                                                                        </td>
                                                                        <td><strong><?php echo e($player->player->number); ?></strong>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="point-table-widget bt-none">
                                                    <table>
                                                        <thead class="background-343e60">
                                                            <tr>
                                                                <th colspan="2"><?php echo e(__('Substitutes')); ?></th>
                                                                <th><?php echo e(__('Jersey')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php if($match[0]->lineups): ?>
                                                                <?php $__currentLoopData = $homeSubstitutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><img src="<?php echo e(asset('public/images/player.jpg')); ?>" class="rounded width-50"></td>
                                                                        
                                                                        <td><strong><?php echo e($player->player->name); ?></strong>
                                                                        </td>
                                                                        <td><strong><?php echo e($player->player->number); ?></strong>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="link-section">
                                                    <div class="row">
                                                        <div class="col-md-9">
                                                            <strong
                                                                class="color-aliceblue"><?php echo e($match[0]->teams->away->name); ?>

                                                                <br />
                                                                <?php echo e(__('Formation')); ?> : <?php echo e($awayFormation); ?> </strong>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <img src="<?php echo e($match[0]->teams->away->logo); ?>" 
                                                                class="float-end width-50-float-right">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="point-table-widget bb-none">
                                                    <table>
                                                        <thead class="background-343e60">
                                                            <tr>
                                                                <th colspan="2"><?php echo e(__('Coach')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td></td>
                                                                <td>
                                                                    <?php echo e($awayCoach->name); ?>

                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="point-table-widget bb-bt-none"
                                                    >
                                                    <table>
                                                        <thead class="background-343e60">
                                                            <tr>
                                                                <th colspan="2"><?php echo e(__('Starting XI')); ?></th>
                                                                <th><?php echo e(__('Jersey')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php if($match[0]->lineups): ?>
                                                                <?php $__currentLoopData = $awayStartXI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><img src="<?php echo e(asset('public/images/player.jpg')); ?>" class="rounded width-50"></td>
                                                                        
                                                                        <td><strong><?php echo e($player->player->name); ?></strong>
                                                                        </td>
                                                                        <td><strong><?php echo e($player->player->number); ?></strong>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="point-table-widget bt-none">
                                                    <table>
                                                        <thead class="background-343e60">
                                                            <tr>
                                                                <th colspan="2"><?php echo e(__('Substitutes')); ?></th>
                                                                <th><?php echo e(__('Jersey')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php if($match[0]->lineups): ?>
                                                                <?php $__currentLoopData = $awaySubstitutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><img src="<?php echo e(asset('public/images/player.jpg')); ?>" class="rounded width-50"></td>
                                                                        
                                                                        <td><strong><?php echo e($player->player->name); ?></strong>
                                                                        </td>
                                                                        <td><strong><?php echo e($player->player->number); ?></strong>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="nav-forwarders" role="tabpanel"
                                    aria-labelledby="nav-3-tab">
                                    <?php if(isset($headToHead)): ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="point-table-widget">
                                                    <table>
                                                        <tbody>
                                                            <?php $__currentLoopData = $headToHead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><img src="<?php echo e($item->teams->home->logo); ?>"
                                                                            
                                                                            class="width-50"><strong><?php echo e($item->teams->home->name); ?>

                                                                        </strong>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <strong><?php echo e($item->goals->home . ' - ' . $item->goals->away); ?></strong>
                                                                    </td>
                                                                    <td class="text-right">
                                                                        <strong><?php echo e($item->teams->away->name); ?>

                                                                        </strong><img src="<?php echo e($item->teams->away->logo); ?>"
                                                                             class="width-50">
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane background-0C1837-border-radius-5" id="nav-statistics" role="tabpanel" aria-labelledby="nav-6-tab">
                                    <?php if($match[0]->statistics): ?>
                                        <?php $__currentLoopData = $match[0]->statistics[0]->statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row mt-10">
                                                <div class="col-lg-12 col-md-12">
                                                    <div class="group-result">
                                                        <div class="last-match-result-full-light background-163268">
                                                            <div class="row">
                                                                <div class="col-4 no-padding">
                                                                    <p class="ml-10-color-whitesmoke">
                                                                        <strong>
                                                                            <?php echo e($item->value); ?> </strong></p>
                                                                </div>
                                                                <div class="col-4 no-padding">
                                                                    <p class="text-center-color-whitesmoke">
                                                                        <strong>
                                                                            <?php echo e($item->type); ?> </strong></p>
                                                                </div>
                                                                <div class="col-4 no-padding">
                                                                    <p class="text-center-mr-10-color-whitesmoke">
                                                                        <strong>
                                                                            <?php echo e($match[0]->statistics[1]->statistics[$key]->value); ?>

                                                                        </strong>
                                                                    </p>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-success"
                                                                            style="width:<?= is_numeric($item->value) ? ($item->value * 100) / ($item->value + $match[0]->statistics[1]->statistics[$key]->value) . '%' : $item->value ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-danger"
                                                                            style="width:<?= is_numeric($match[0]->statistics[1]->statistics[$key]->value) ? ($match[0]->statistics[1]->statistics[$key]->value * 100) / ($item->value + $match[0]->statistics[1]->statistics[$key]->value) . '%' : $match[0]->statistics[1]->statistics[$key]->value ?> ">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane fade" id="nav-team" role="tabpanel" aria-labelledby="nav-7-tab">
                                    <div class="container">
                                        <div class="accordion" id="accordionExample">
                                            <?php if($match[0]->players): ?>
                                                <?php $__currentLoopData = $match[0]->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $players): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-6 col-lg-6 col-12">
                                                        <div class="match-results-table">
                                                            <table>
                                                                <tr>
                                                                    <td><?php echo e(__('Team')); ?></td>
                                                                    <td><?php echo e($players->team->name); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td><?php echo e(__('Logo')); ?></td>
                                                                    <td><img src="<?php echo e($players->team->logo); ?>"
                                                                             class="rounded width-50-padding-7"
                                                                            ></td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>

                                                    <?php $__currentLoopData = $players->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="item">
                                                            <div class="item-header" id="<?= $key ?>">
                                                                <h2 class="mb-0">
                                                                    <button class="btn btn-link" type="button"
                                                                        data-toggle="collapse"
                                                                        data-target="#collapseOne<?= $key ?>"
                                                                        aria-expanded="true"
                                                                        aria-controls="collapseOne<?= $key ?>">
                                                                        <img src="<?php echo e($player->player->photo); ?>"
                                                                             class="rounded-circle width-50">
                                                                        <?php echo e($player->player->name); ?>

                                                                        <i class="fe-chevron-down"></i>
                                                                    </button>
                                                                </h2>
                                                            </div>
                                                            <div id="collapseOne<?= $key ?>"
                                                                class="collapse <?php echo e($key == 0 ? 'show' : ''); ?>"
                                                                aria-labelledby="headingOne<?= $key ?>"
                                                                data-parent="#accordionExample">
                                                                <?php $__currentLoopData = $player->statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="match-players mt-10">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="team-palyers table-responsive">
                                                                                    <h4 class="background-3fca7c">
                                                                                        <?php echo e(__('Games')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Minutes')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Number')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Position')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Rating')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Captain')); ?></strong>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->games->minutes); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->games->number); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->games->position); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->games->rating); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->games->captain); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div
                                                                                    class="team-palyers table-responsive c2">
                                                                                    <h4><?php echo e(__('Shots')); ?></h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Total')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('On')); ?></strong>
                                                                                                </td>

                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->shots->total); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->shots->on); ?>

                                                                                                </td>

                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="match-players">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="team-palyers table-responsive">
                                                                                    <h4 class="background-e81f3e">
                                                                                        <?php echo e(__('Goals')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Total')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Conceded')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Assists')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Saves')); ?></strong>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->goals->total); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->goals->conceded); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->goals->assists); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->goals->saves); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div
                                                                                    class="team-palyers table-responsive c2">
                                                                                    <h4 class="background-171e36">
                                                                                        <?php echo e(__('Passes')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Total')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Key')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Accuracy')); ?></strong>
                                                                                                </td>

                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->passes->total); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->passes->key); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->passes->accuracy); ?>

                                                                                                </td>

                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="match-players">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="team-palyers table-responsive">
                                                                                    <h4 class="background-8db13d">
                                                                                        <?php echo e(__('Tackles')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Total')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Blocks')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Interceptions')); ?></strong>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->tackles->total); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->tackles->blocks); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->tackles->interceptions); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div
                                                                                    class="team-palyers table-responsive c2">
                                                                                    <h4 class="background-1234a8">
                                                                                        <?php echo e(__('Duels')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Total')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('won')); ?></strong>
                                                                                                </td>

                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->duels->total); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->duels->won); ?>

                                                                                                </td>

                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="match-players">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="team-palyers table-responsive">
                                                                                    <h4 class="background-78ca3f">
                                                                                        <?php echo e(__('Dribbles')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Attempts')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Success')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Past')); ?></strong>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->dribbles->attempts); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->dribbles->success); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->dribbles->past); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div
                                                                                    class="team-palyers table-responsive c2">
                                                                                    <h4 class="background-127ea8">
                                                                                        <?php echo e(__('Fouls')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Drawn')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Committed')); ?></strong>
                                                                                                </td>

                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->fouls->drawn); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->fouls->committed); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="match-players">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="team-palyers table-responsive">
                                                                                    <h4 class="background-3fca7c">
                                                                                        <?php echo e(__('Cards')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Yellow')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Red')); ?></strong>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->cards->yellow); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->cards->red); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div
                                                                                    class="team-palyers table-responsive c2">
                                                                                    <h4 class="background-12a893">
                                                                                        <?php echo e(__('Penalty')); ?>

                                                                                    </h4>
                                                                                    <table>
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td><strong><?php echo e(__('Won')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Committed')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Scored')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Missed')); ?></strong>
                                                                                                </td>
                                                                                                <td><strong><?php echo e(__('Saved')); ?></strong>
                                                                                                </td>

                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><?php echo e($statistic->penalty->won); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->penalty->commited); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->penalty->scored); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->penalty->missed); ?>

                                                                                                </td>
                                                                                                <td><?php echo e($statistic->penalty->saved); ?>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="sidebar mb-10">
                            <!--widget start-->
                            <?php echo $__env->make('front.upcomingMatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--widget end-->
                        </div>
                        <div class="h3-section-title"> <strong><?php echo e(__('Trending News')); ?></strong></div>
                        <div class="trending-news">
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!--Expand-->
                                <div class="list-box-expand <?= $key == 0 ? 'active' : '' ?>">
                                    <div class="news-caption">
                                        <div class="news-txt">
                                            <h4><a
                                                    href="<?php echo e(route('news.detail', [$item->id, str_replace([' ', '_', '&'], '-', strtolower($item->title))])); ?>"><?php echo e($item->title); ?></a>
                                            </h4>
                                            <ul class="news-meta">
                                                <li><i class="fe-calendar"></i>
                                                    <?php echo e(date('D M, Y', strtotime($item->date))); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="expand-news-img"><img
                                            src="<?php echo e(file_exists($item->photo) ? asset($item->photo) : asset('public/images/news.jpg')); ?>"
                                            ></div>
                                </div>
                                <!--Expand-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="sidebar">
                            <!--widget start-->
                            <div class="widget">
                                <h4><?php echo e(__('Featured Videos')); ?> </h4>
                                <div class="featured-video-widget">
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="fvideo-box mb15">
                                            <div class="fvid-cap">
                                                <h5><a
                                                        href="https://www.youtube.com/watch?v=<?= $item->link ?>"><?php echo e($item->title); ?></a>
                                                </h5>
                                                <span><i class="fe-clock"></i>
                                                    <?php echo e(date('d M, Y', strtotime($item->date))); ?> </span>
                                            </div>
                                            <img src="https://img.youtube.com/vi/<?= $item->link ?>/1.jpg" >
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <!--widget end-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Sports Widgets End-->
    </div>
    <!--Main Content End-->

    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <?php if($finishDiff > 120): ?>
                        <h3 class="text-center-color-red"><?php echo e(__('Live video is not available as this match has finished! ')); ?></h3>
                    <?php else: ?>
                        <h3 class="text-center-color-red"><?php echo e(__('Live video will be available 30 minutes prior to the match start! ')); ?></h3>
                    <?php endif; ?>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/front/match/detail.blade.php ENDPATH**/ ?>