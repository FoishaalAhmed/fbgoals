

<?php $__env->startSection('title', __('Football Top Leagues - :x', ['x' => settings('name')])); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/leagues.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--Main Content Start-->
    <div class="main-content innerpagebg wf100">
        <!--team Page Start-->
        <div class="team wf100 p80">
            <!--Start-->
            <div class="player-squad">
                <div class="container">
                    <div class="row">
                        <!--Fixture Start-->
                        <div class="col-lg-8">
                            <!--Mathes Grid-->
                            <div class="fixtures-light fixtures-grid np">
                                <div class="row">
                                    <?php if($leagues): ?>
                                        <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!--col start-->
                                            <div class="col-lg-6 p-10">
                                                <a
                                                    href="<?php echo e(route('leagues.matches', [$item['id'], str_replace([' ', '_', '&'], '-', strtolower($item['name']))])); ?>">
                                                    <div class="next-match-fixtures">
                                                        <ul class="match-teams-vs">
                                                            <li class="team-logo"><img src="<?php echo e($item['logo']); ?>"
                                                                    class="width-height-50">
                                                            </li>
                                                            <li class="mvs">
                                                                <p><strong><?php echo e($item['name'] . ', ' . $item['country']); ?></strong>
                                                                </p>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </a>
                                            </div>
                                            <!--col end-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </div>
                            </div>
                            <!--Mathes Grid-->
                        </div>
                        <!--Fixture End-->
                        <!--Sidebar Start-->
                        <div class="col-lg-4">
                            <div class="sidebar mb-10">
                                <!--widget start-->
                                <?php echo $__env->make('front.upcomingMatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <!--widget end-->
                            </div>
                            <div class="h3-section-title"> <strong><?php echo e(__('Trending News')); ?></strong></div>
                            <div class="trending-news">
                                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--Expand-->
                                    <div class="list-box-expand <?= $key == 0 ? 'active' : '' ?>">
                                        <div class="news-caption">
                                            <div class="news-txt">
                                                <h4><a
                                                        href="<?php echo e(route('news.detail', [$item->id, str_replace([' ', '_', '&'], '-', strtolower($item->title))])); ?>"><?php echo e($item->title); ?></a>
                                                </h4>
                                                <ul class="news-meta">
                                                    <li><i class="fe-calendar"></i>
                                                        <?php echo e(date('D M, Y', strtotime($item->date))); ?></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="expand-news-img"><img
                                                src="<?php echo e(file_exists($item->photo) ? asset($item->photo) : asset('public/images/news.jpg')); ?>">
                                        </div>
                                    </div>
                                    <!--Expand-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="sidebar">
                                <!--widget start-->
                                <div class="widget">
                                    <h4><?php echo e(__('Featured Videos')); ?> </h4>
                                    <div class="featured-video-widget">
                                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="fvideo-box mb15">
                                                <div class="fvid-cap">
                                                    <h5><a
                                                            href="https://www.youtube.com/watch?v=<?= $item->link ?>"><?php echo e($item->title); ?></a>
                                                    </h5>
                                                    <span><i class="fe-clock"></i>
                                                        <?php echo e(date('d M, Y', strtotime($item->date))); ?> </span>
                                                </div>
                                                <img src="https://img.youtube.com/vi/<?= $item->link ?>/1.jpg">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <!--widget end-->
                            </div>
                        </div>
                        <!--Sidebar End-->
                    </div>
                </div>
            </div>
            <!--End-->
        </div>
        <!--team Page End-->
    </div>
    <!--Main Content End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/front/leagues/index.blade.php ENDPATH**/ ?>