<div class="auth-brand">
    <a href="<?php echo e(url('/')); ?>" class="logo logo-dark text-center">
        <span class="logo-lg">
            <img src="<?php echo e(asset(lightLogo())); ?>" alt="" height="22">
        </span>
    </a>

    <a href="<?php echo e(url('/')); ?>" class="logo logo-light text-center">
        <span class="logo-lg">
            <img src="<?php echo e(asset(darkLogo())); ?>" alt="" height="22">
        </span>
    </a>
</div>
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/auth/layouts/logo.blade.php ENDPATH**/ ?>