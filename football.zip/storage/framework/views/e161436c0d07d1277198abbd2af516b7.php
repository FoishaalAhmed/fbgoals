<?php
    $my_date_time = date('Y-m-d H:i:s');
?>
<?php if($upcomingMatchData): ?>
    <?php
        $my_date_time = date('Y-m-d H:i:s', strtotime($upcomingMatchData[0]->fixture->date));
    ?>
    <div class="widget">
        <h4><?php echo e($upcomingMatch->title); ?> </h4>
        <div class="last-match-widget">
            <p> <strong><?php echo e($upcomingMatchData[0]->league->name . ', ' . $upcomingMatchData[0]->league->country); ?></strong>
                <?php echo e(date('d M, Y', strtotime($upcomingMatchData[0]->fixture->date))); ?> |
                <?php echo e(date('h:i A', strtotime($upcomingMatchData[0]->fixture->date))); ?> </p>
            <ul class="match-teams-vs">
                <li class="team-logo"><img src="<?php echo e($upcomingMatchData[0]->teams->home->logo); ?>" class="width-50"> <strong><?php echo e($upcomingMatchData[0]->teams->home->name); ?></strong> </li>
                <li class="mvs"> <span class="vs">VS</span> </li>
                <li class="team-logo"><img src="<?php echo e($upcomingMatchData[0]->teams->away->logo); ?>" class="width-50">
                    <strong><?php echo e($upcomingMatchData[0]->teams->away->name); ?></strong>
                </li>
            </ul>
            <p class="mloc"> <i class="fe-map-pin"></i>
                <?php echo e($upcomingMatchData[0]->fixture->venue->name . ', ' . $upcomingMatchData[0]->fixture->venue->city); ?>

            </p>
            <div class="defaultCountdown is-countdown">
                <span class="countdown-row countdown-show4">
                    <span class="countdown-section"><span class="countdown-amount" id="day"></span><span
                            class="countdown-period"><?php echo e(__('Days')); ?></span></span>
                    <span class="countdown-section"><span class="countdown-amount" id="hour"></span><span
                            class="countdown-period"><?php echo e(__('Hour')); ?></span></span>
                    <span class="countdown-section"><span class="countdown-amount" id="min"></span><span
                            class="countdown-period"><?php echo e(__('Minutes')); ?></span></span>
                    <span class="countdown-section"><span class="countdown-amount" id="sec"></span><span
                            class="countdown-period"><?php echo e(__('Seconds')); ?></span></span>
                </span>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->startSection('js'); ?>
    <script>
        'use script';
        var myDateTime = "<?php echo e($my_date_time); ?>";
    </script>
    <script src="<?php echo e(asset('public/assets/front/js/upcoming.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\wamp64\www\football\resources\views/front/upcomingMatch.blade.php ENDPATH**/ ?>