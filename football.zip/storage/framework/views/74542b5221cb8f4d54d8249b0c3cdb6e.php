

<?php $__env->startSection('title', __('System Settings')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <h4 class="header-title"><?php echo e(__('System Settings')); ?></h4>
                        <form action="<?php echo e(route('admin.settings.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label for="dark-logo"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Dark Logo')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="file" id="dark-logo-input" class="form-control" name="dark_logo">
                                    <p class="font-13 text-muted mb-2 fw-bolder">
                                        <?php echo e(__('*Recommended Dimension: 98 px * 20 px')); ?></p>
                                    <img src="<?php echo e(asset(darkLogo())); ?>" alt="<?php echo e(__('Dark Logo')); ?>" class="large-logo"
                                        id="dark-logo-photo">
                                    <?php $__errorArgs = ['dark_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="light-logo"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Light Logo')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="file" id="light-logo-input" class="form-control" name="light_logo">
                                    <p class="font-13 text-muted mb-2 fw-bolder">
                                        <?php echo e(__('*Recommended Dimension: 98 px * 20 px')); ?></p>
                                    <img src="<?php echo e(asset(lightLogo())); ?>" alt="<?php echo e(__('Light Logo')); ?>" class="large-logo"
                                        id="light-logo-photo">
                                    <?php $__errorArgs = ['light_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="small-logo"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Small Logo')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="file" id="small-logo-input" class="form-control" name="small_logo">
                                    <p class="font-13 text-muted mb-2 fw-bolder">
                                        <?php echo e(__('*Recommended Dimension: 22 px * 22 px')); ?></p>
                                    <img src="<?php echo e(asset(smallLogo())); ?>" alt="<?php echo e(__('Small Logo')); ?>" class="small-logo"
                                        id="small-logo-photo">
                                    <?php $__errorArgs = ['small_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="favicon"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Favicon')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="file" id="favicon-input" class="form-control" name="favicon">
                                    <p class="font-13 text-muted mb-2 fw-bolder">
                                        <?php echo e(__('*Recommended Dimension: 22 px * 22 px')); ?></p>

                                    <img src="<?php echo e(asset(getFavIcon())); ?>" alt="<?php echo e(__('Favicon')); ?>" class="small-logo"
                                        id="favicon-photo">

                                    <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="name"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Name')); ?> <span class="text-danger"> * </span></label>
                                <div class="col-8 col-xl-4">
                                    <input type="text" id="name" class="form-control" name="name" required="" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(settings('name')); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="email"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Email')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="email" id="email" class="form-control" name="email"
                                        placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(settings('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="phone"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Phone')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="text" id="phone" class="form-control" name="phone" 
                                        placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e(settings('phone')); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="address"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Address')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <input type="text" id="address" class="form-control" name="address"
                                        placeholder="<?php echo e(__('Address')); ?>" value="<?php echo e(settings('address')); ?>">
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="api_key"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Api Key')); ?> <span class="text-danger"> * </span></label>
                                <div class="col-8 col-xl-4">
                                    <input type="text" id="api_key" class="form-control" name="api_key"
                                        placeholder="<?php echo e(__('Api Key')); ?>" value="<?php echo e(settings('api_key')); ?>" required="">
                                    <?php $__errorArgs = ['api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="google_tracking"
                                    class="col-4 col-xl-2 offset-lg-3 col-form-label text-end"><?php echo e(__('Google Analytics Tracking Code')); ?></label>
                                <div class="col-8 col-xl-4">
                                    <textarea name="google_tracking" class="form-control" id="google_tracking" rows="5" placeholder="<?php echo e(__('Google Analytics Tracking Code')); ?>"><?php echo e(settings('google_tracking')); ?></textarea>
                                    <?php $__errorArgs = ['google_tracking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="<?php echo e(route('admin.settings.create')); ?>"
                                        class="btn btn-outline-danger waves-effect waves-light"><i class="fe-delete"></i>
                                        <?php echo e(__('Cancel')); ?></a>
                                    <button type="submit" class="btn btn-outline-success waves-effect waves-light"><i
                                            class="fe-plus-circle"></i> <?php echo e(__('Submit')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('public/assets/backend/js/custom/setting.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/admin/setting.blade.php ENDPATH**/ ?>