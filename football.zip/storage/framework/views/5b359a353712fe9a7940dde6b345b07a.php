

<?php $__env->startSection('title', __('New Page')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <h4 class="header-title"><?php echo e(__('New Page')); ?></h4>
                        <p class="text-muted font-13 mb-4 text-end mt-n4">
                            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-outline-primary waves-effect waves-light"><i class="fe-list"></i> <?php echo e(__('All Page')); ?></a>
                        </p>
                        <form action="<?php echo e(route('admin.pages.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="title" class="form-label"><?php echo e(__('Title')); ?> <span class="text-danger"> * </span></label>
                                    <input type="text" name="title" id="title" class="form-control" placeholder="<?php echo e(__('Title')); ?>" required="" value="<?php echo e(old('title')); ?>">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="position" class="form-label"><?php echo e(__('Position')); ?> <span class="text-danger"> * </span></label>
                                    <select class="form-select" name="position" id="example-select" required="">
                                        <option value="Header" <?php echo e(old('position') == 'Header' ? 'selected' : ''); ?>><?php echo e(__('Header')); ?></option>
                                        <option value="Footer" <?php echo e(old('position') == 'Footer' ? 'selected' : ''); ?>><?php echo e(__('Footer')); ?></option>
                                        <option value="Both" <?php echo e(old('position') == 'Both' ? 'selected' : ''); ?>><?php echo e(__('Both')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label for="content" class="form-label"><?php echo e(__('Content')); ?> <span class="text-danger"> * </span></label>
                                    <textarea name="content" id="editor"><?php echo e(old('content')); ?></textarea>
                                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-outline-danger waves-effect waves-light"><i class="fe-delete"></i> <?php echo e(__('Cancel')); ?></a>
                                    <button type="submit" class="btn btn-outline-success waves-effect waves-light"><i class="fe-plus-circle"></i> <?php echo e(__('Submit')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('public/assets/backend/js/pages/ckeditor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/js/pages/form-pickers.init.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/js/custom/page.min.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/admin/pages/create.blade.php ENDPATH**/ ?>