

<?php $__env->startSection('title', "$title"); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/leagues.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $status = ['1H', 'HT', '2H', 'ET', 'FT'];
        $liveStatus = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'INT', 'LIVE'];
        $leagueId = null;
    ?>

    <!--Main Content Start-->
    <div class="main-content wf100">

        <!--Sports Widgets Start-->
        <section class="wf100 p80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <?php echo $__env->make('front.leagues.secondMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!--pagination-->
                        <div class="row">
                            <div class="gt-pagination">
                                <nav aria-label="Page navigation example">
                                    <?php echo e($matches->links('front.pagination')); ?>

                                </nav>
                            </div>
                        </div>
                        <?php if($matches): ?>
                            <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($leagueId != $match['leagueId']): ?>
                                    <div class="row">
                                        <div class="col-12">
                                            <nav>
                                                <div class="nav" id="nav-tab" role="tablist">
                                                    <a class="nav-item nav-link nav-active-home league-title" id="nav-1-tab"
                                                        data-toggle="tab" href="#nav-defenders" role="tab"
                                                        aria-controls="nav-defenders" aria-selected="true"><?php echo e($match['league']); ?></a>
                                                </div>
                                            </nav>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="last-match-result-full-light"
                                    onclick="redirectToURL('<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>')">
                                    <div class="row">
                                        <div class="col-5 no-padding">
                                            <div class="match-left">
                                                <div class="mtl-left"> <img src="<?php echo e($match['homeTeamLogo']); ?>"
                                                        alt="">
                                                    <strong><a class="color-bcc9ea"
                                                            href="<?php echo e(route('teams.matches', [$match['homeTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['homeTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['homeTeamName']); ?></a></strong>
                                                </div>
                                                <?php if(in_array($match['shortStatus'], $status)): ?>
                                                    <div class="mscore float-right">
                                                        <strong><?php echo e($match['homeTeamGoal']); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-2 no-padding">
                                            <div class="lmr-info">
                                                <?php if($match['shortStatus'] === 'NS'): ?>
                                                    <strong class="color-14844d">
                                                        <?php echo e(date('d/m  h:i A', $match['date'])); ?> </strong>
                                                <?php endif; ?>

                                                <?php if(in_array($match['shortStatus'], $status)): ?>
                                                    <strong
                                                        class="color-6ed950-font-15"><?php echo e($match['elapsed'] . '"'); ?></strong>
                                                <?php endif; ?>

                                                <a href="<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>"
                                                    class="mh"><?php echo e(in_array($match['fixtureId'], $matchArray) && in_array($match['shortStatus'], $liveStatus) ? __('Watch Live') : $match['longStatus']); ?></a>

                                            </div>
                                        </div>
                                        <div class="col-5 no-padding">
                                            <div class="match-right">
                                                <?php if(in_array($match['shortStatus'], $status)): ?>
                                                    <div class="mscore">
                                                        <strong><?php echo e($match['awayTeamGoal']); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="mtl-right"> <img src="<?php echo e($match['awayTeamLogo']); ?>"
                                                        alt="">
                                                    <strong><a class="color-bcc9ea"
                                                            href="<?php echo e(route('teams.matches', [$match['awayTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['awayTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['awayTeamName']); ?></a></strong>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    $leagueId = $match['leagueId'];
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                    <!--Sidebar Start-->
                    <div class="col-lg-4">
                        <div class="sidebar mb-10">
                            <!--widget start-->
                            <?php echo $__env->make('front.upcomingMatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--widget end-->
                        </div>
                        <?php if($news->isNotEmpty()): ?>
                            <div class="h3-section-title"> <strong><?php echo e(__('Trending News')); ?></strong></div>
                            <div class="trending-news">
                                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--Expand-->
                                    <div class="list-box-expand <?= $key == 0 ? 'active' : '' ?>">
                                        <div class="news-caption">
                                            <div class="news-txt">
                                                <h4><a
                                                        href="<?php echo e(route('news.detail', [$item->id, str_replace([' ', '_', '&'], '-', strtolower($item->title))])); ?>"><?php echo e($item->title); ?></a>
                                                </h4>
                                                <ul class="news-meta">
                                                    <li><i class="fe-calendar"></i>
                                                        <?php echo e(date('D M, Y', strtotime($item->date))); ?></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="expand-news-img"><img
                                                src="<?php echo e(file_exists($item->photo) ? asset($item->photo) : asset('public/images/news.jpg')); ?>"
                                                alt=""></div>
                                    </div>
                                    <!--Expand-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if($videos->isNotEmpty()): ?>
                            <div class="sidebar">
                                <!--widget start-->
                                <div class="widget">
                                    <h4><?php echo e(__('Featured Videos')); ?> </h4>
                                    <div class="featured-video-widget">
                                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="fvideo-box mb15">
                                                <div class="fvid-cap">
                                                    <h5><a
                                                            href="https://www.youtube.com/watch?v=<?= $item->link ?>"><?php echo e($item->title); ?></a>
                                                    </h5>
                                                    <span><i class="fe-clock"></i>
                                                        <?php echo e(date('d M, Y', strtotime($item->date))); ?> </span>
                                                </div>
                                                <img src="https://img.youtube.com/vi/<?= $item->link ?>/1.jpg"
                                                    alt="">
                                                <h5><a
                                                        href="https://www.youtube.com/watch?v=<?= $item->link ?>"><?php echo e($item->title); ?></a>
                                                </h5>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <!--widget end-->
                            </div>
                        <?php endif; ?>
                    </div>
                    <!--Sidebar End-->
                </div>
            </div>
        </section>
        <!--Sports Widgets End-->
    </div>
    <!--Main Content End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/front/leagues/matches.blade.php ENDPATH**/ ?>