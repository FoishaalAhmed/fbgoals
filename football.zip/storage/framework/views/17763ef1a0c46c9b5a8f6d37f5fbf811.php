<link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/secondmenu.min.css')); ?>">


<div class="row b-272f46-mb-10">
    <div class="col-md-3">
        <div class="nms-title b-transparent">
            <h4><a class="<?php echo e(request()->is('league-matches/*') ? 'active' : ''); ?>" href="<?php echo e(route('leagues.matches', [$league, $name])); ?>"><?php echo e(__('Fixture')); ?></a></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="nms-title b-transparent">
            <h4><a class="<?php echo e(request()->is('league-recent-matches/*') ? 'active' : ''); ?>" href="<?php echo e(route('leagues.recent', [$league, $name])); ?>"><?php echo e(__('Recent')); ?></a></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="nms-title b-transparent">
            <h4><a class="<?php echo e(request()->is('league-standing/*') ? 'active' : ''); ?>" href="<?php echo e(route('leagues.standings', [$league, $name])); ?>"><?php echo e(__('Standings')); ?></a>
            </h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="nms-title b-transparent">
            <h4><a class="<?php echo e(request()->is('league-scores/*') ? 'active' : ''); ?>" href="<?php echo e(route('leagues.scores', [$league, $name])); ?>"><?php echo e(__('Top Score')); ?></a></h4>
        </div>
    </div>
</div>


<?php /**PATH C:\wamp64\www\football\resources\views/front/leagues/secondMenu.blade.php ENDPATH**/ ?>