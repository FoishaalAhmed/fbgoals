

<?php $__env->startSection('title', __('All Page')); ?>
<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('public/assets/backend/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('public/assets/backend/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>"
        rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <h4 class="header-title"><?php echo e(__('All Page')); ?></h4>
                        <p class="text-muted font-13 mb-4 text-end mt-n4">
                            <a href="<?php echo e(route('admin.pages.create')); ?>"
                                class="btn btn-outline-primary waves-effect waves-light"><i class="fe-plus-square"></i>
                                <?php echo e(__('New Page')); ?></a>
                        </p>
                        <div class="table-responsive">
                            <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Sl')); ?></th>
                                        <th><?php echo e(__('Title')); ?></th>
                                        <th><?php echo e(__('Position')); ?></th>
                                        <th><?php echo e(__('Status')); ?></th>
                                        <th><?php echo e(__('Content')); ?></th>
                                        <th><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($item->title); ?> </td>
                                            <td><?php echo e($item->position); ?> </td>
                                            <td><?php echo e($item->status); ?> </td>
                                            <td><?php echo e(Str::limit($item->content, 100)); ?> </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.pages.edit', $item->id)); ?>"
                                                    class="btn btn-outline-success waves-effect waves-light"><i
                                                        class="fe-edit"></i></a>
                                                <a href="<?php echo e(route('admin.pages.destroy', [$item->id])); ?>" class="btn btn-outline-danger waves-effect waves-light delete-warning"><i class="fe-delete"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div> <!-- end card body-->
                </div> <!-- end card -->

            </div><!-- end col-->
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- third party js -->
    <script src="<?php echo e(asset('public/assets/backend/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <!-- Datatables init -->
    <script src="<?php echo e(asset('public/assets/backend/js/pages/datatables.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/admin/pages/index.blade.php ENDPATH**/ ?>