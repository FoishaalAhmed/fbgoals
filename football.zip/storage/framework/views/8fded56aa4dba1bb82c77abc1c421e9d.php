<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div><script>document.write(new Date().getFullYear())</script> © <?php echo e(settings('name')); ?></div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer --><?php /**PATH C:\wamp64\www\football\resources\views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>