

<?php $__env->startSection('title', __('New User')); ?>

<?php $__env->startSection('css'); ?>
    <!-- Plugins css -->
    <link href="<?php echo e(asset('public/assets/backend/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <h4 class="header-title"><?php echo e(__('New User')); ?></h4>
                        <p class="text-muted font-13 mb-4 text-end mt-n4">
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-primary waves-effect waves-light"><i class="fe-list"></i> <?php echo e(__('All User')); ?></a>
                        </p>
                        <form action="<?php echo e(route('admin.users.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label for="name" class="form-label"><?php echo e(__('Name')); ?> <span class="text-danger"> * </span></label>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(__('Name')); ?>" required="" value="<?php echo e(old('name')); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="email" class="form-label"><?php echo e(__('Email')); ?> <span class="text-danger"> * </span></label>
                                    <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e(__('Email')); ?>" required="" value="<?php echo e(old('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="phone" class="form-label"><?php echo e(__('Phone')); ?> <span class="text-danger"> * </span></label>
                                    <input type="tel" name="phone" id="phone" class="form-control" placeholder="<?php echo e(__('Phone')); ?>" required="" value="<?php echo e(old('phone')); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="password" class="form-label"><?php echo e(__('Password')); ?> <span class="text-danger"> * </span></label>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(__('Password')); ?>" required="">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="password_confirmation" class="form-label"><?php echo e(__('Confirm Password')); ?> <span class="text-danger"> * </span></label>
                                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="<?php echo e(__('Confirm Password')); ?>" required="">
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label for="permission" class="form-label"><?php echo e(__('Permission')); ?> <span class="text-danger"> * </span></label>
                                    <select class="form-control select2-multiple" name="permission[]" data-toggle="select2" data-width="100%" multiple="multiple" data-placeholder="<?php echo e(__('Choose Preferred permission')); ?>">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label for="address" class="form-label"><?php echo e(__('Address')); ?> <span class="text-danger"> * </span></label>
                                    <textarea name="address" class="form-control" id="address" placeholder="<?php echo e(__('Address')); ?>" rows="5" required=""><?php echo e(old('address')); ?></textarea>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-danger waves-effect waves-light"><i class="fe-delete"></i> <?php echo e(__('Cancel')); ?></a>
                                    <button type="submit" class="btn btn-outline-success waves-effect waves-light"><i class="fe-plus-circle"></i> <?php echo e(__('Submit')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Init js-->
    <script src="<?php echo e(asset('public/assets/backend/libs/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/js/pages/form-advanced.init.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/backend/js/pages/form-pickers.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/admin/users/create.blade.php ENDPATH**/ ?>