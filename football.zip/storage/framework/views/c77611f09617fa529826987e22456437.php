

<?php $__env->startSection('title', __('Leagues')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <h4 class="header-title mb-4"><?php echo e(__('Leagues')); ?></h4>
                        <form action="<?php echo e(route('admin.leagues.update', $league->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <!-- Leagues -->
                                <div class="col-lg-12 mb-3">
                                    <label for="leagues" class="form-label"><?php echo e(__('Leagues')); ?> <span class="text-danger"> * </span></label>
                                    <textarea class="form-control" name="leagues" placeholder="<?php echo e(__('Leagues')); ?>" id="leagues" rows="5"><?php echo e(old('leagues', $league->leagues)); ?></textarea>
                                    <?php $__errorArgs = ['leagues'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="<?php echo e(route('admin.leagues.edit')); ?>" class="btn btn-outline-danger waves-effect waves-light"><i class="fe-delete"></i> <?php echo e(__('Cancel')); ?></a>
                                    <button type="submit" class="btn btn-outline-success waves-effect waves-light"><i class="fe-plus-circle"></i> <?php echo e(__('Submit')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/admin/league.blade.php ENDPATH**/ ?>