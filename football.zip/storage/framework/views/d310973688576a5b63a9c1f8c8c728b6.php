

<?php $__env->startSection('title', __('Socials')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card-body">
                        <h4 class="header-title mb-4"><?php echo e(__('Socials')); ?></h4>
                        <form action="<?php echo e(route('admin.socials.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="facebook" class="form-label"><?php echo e(__('Facebook')); ?></label>
                                    <input type="text" name="facebook" id="facebook" class="form-control" placeholder="<?php echo e(__('Facebook')); ?>" value="<?php echo e(old('facebook', $social->facebook ?? '')); ?>">
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="twitter" class="form-label"><?php echo e(__('Twitter')); ?></label>
                                    <input type="text" name="twitter" id="twitter" class="form-control" placeholder="<?php echo e(__('Twitter')); ?>" value="<?php echo e(old('twitter', $social->twitter ?? '')); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="linkedin" class="form-label"><?php echo e(__('Linkedin')); ?></label>
                                    <input type="text" name="linkedin" id="linkedin" class="form-control" placeholder="<?php echo e(__('Linkedin')); ?>" value="<?php echo e(old('linkedin', $social->linkedin ?? '')); ?>">
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="pinterest" class="form-label"><?php echo e(__('Pinterest')); ?></label>
                                    <input type="text" name="pinterest" id="pinterest" class="form-control" placeholder="<?php echo e(__('Pinterest')); ?>" value="<?php echo e(old('pinterest', $social->pinterest ?? '')); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="youtube" class="form-label"><?php echo e(__('Youtube')); ?></label>
                                    <input type="text" name="youtube" id="youtube" class="form-control" placeholder="<?php echo e(__('Youtube')); ?>" value="<?php echo e(old('youtube', $social->youtube ?? '')); ?>">
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label for="instagram" class="form-label"><?php echo e(__('Instagram')); ?></label>
                                    <input type="text" name="instagram" id="instagram" class="form-control" placeholder="<?php echo e(__('Instagram')); ?>" value="<?php echo e(old('instagram', $social->instagram ?? '')); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="<?php echo e(route('admin.socials.edit')); ?>" class="btn btn-outline-danger waves-effect waves-light"><i class="fe-delete"></i> <?php echo e(__('Cancel')); ?></a>
                                    <button type="submit" class="btn btn-outline-success waves-effect waves-light"><i class="fe-plus-circle"></i> <?php echo e(__('Submit')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div>
        <!-- end row-->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/backend/admin/social.blade.php ENDPATH**/ ?>