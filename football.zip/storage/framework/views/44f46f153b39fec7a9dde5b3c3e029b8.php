<?php $__env->startSection('title', __('Football Teams, Scores, Stats, News, Fixtures, Results, Tables - :x' , ['x' => settings('name')])); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/home.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--Main Content Start-->
    <div class="main-content wf100">

        <?php
            $liveStatus = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'INT', 'LIVE'];
            $statusArray = ['TBD', 'NS', 'PST', 'CANC', 'ABD', 'AWD', 'WO'];
            $sl = 100;
        ?>

        <!--Sports Widgets Start-->
        <section class="wf100 p80">
            <div class="container">
                <div class="row">

                    <?php if(session()->has('error')): ?>
                        <div class="col-md-12">
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong><?php echo e(session('error')); ?></strong>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="col-lg-3 col-md-3">
                        <div class="point-table-widget mb-10">
                            <table>
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Leagues')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('leagues.matches', [1, 'world-cup'])); ?>"><img src="https://media.api-sports.io/football/leagues/1.png" class="img-class"> <strong class="text-align">World Cup, World</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [39, 'premier-league'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/39.png" 
                                                 class="img-class">
                                                <strong class="text-align">Premier League,
                                                    England</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [135, 'serie-a'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/135.png"
                                                     class="img-class">
                                                <strong class="text-align">Serie A, Italy</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [2, 'uefa-champions-league'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/2.png" 
                                                 class="img-class">
                                                <strong class="text-align">UEFA Champions League,
                                                    World</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [3, 'uefa-europa-league'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/3.png" 
                                                 class="img-class">
                                                <strong class="text-align">UEFA Europa League,
                                                    World</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [6, 'africa-cup-of-nations'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/6.png" 
                                                 class="img-class">
                                                <strong class="text-align">Africa Cup of Nations,
                                                    World</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [9, 'copa-america'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/9.png" 
                                                 class="img-class">
                                                <strong class="text-align">Copa America,
                                                    World</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('leagues.matches', [10, 'friendlies'])); ?>"><img
                                                    src="https://media.api-sports.io/football/leagues/10.png" 
                                                 class="img-class">
                                                <strong class="text-align">Friendlies,
                                                    World</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><a href="<?php echo e(route('leagues')); ?>">
                                                <strong><?php echo e(__('View All')); ?></strong></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="trending-news">
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!--Expand-->
                                <div class="list-box-expand <?= $key == 0 ? 'active' : '' ?>">
                                    <div class="news-caption">
                                        <div class="news-txt">
                                            <h4><a  href="<?php echo e(route('news.detail', [$item->id, str_replace([' ', '_', '&'], '-', strtolower($item->title))])); ?>"><?php echo e($item->title); ?></a>
                                            </h4>
                                            <ul class="news-meta">
                                                <li><i class="fe-calendar"></i>
                                                    <?php echo e(date('D M, Y', strtotime($item->date))); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="expand-news-img"><img src="<?php echo e($item->image); ?>"></div>
                                </div>
                                <!--Expand-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="row">
                            <div class="col-12">
                                <nav>
                                    <div class="nav" id="nav-tab" role="tablist">
                                        <a class="nav-item nav-link nav-active-home" id="nav-1-tab" data-toggle="tab"
                                            href="#nav-defenders" role="tab" aria-controls="nav-defenders"
                                            aria-selected="true"><?php echo e(__('Live Matches')); ?></a>

                                        <a class="nav-item nav-link nav-active-home active" id="nav-2-tab" data-toggle="tab"
                                            href="#nav-gk" role="tab" aria-controls="nav-gk"
                                            aria-selected="false"><?php echo e(__('Today\'s Matches')); ?></a>
                                    </div>
                                </nav>
                            </div>
                        </div>
                        <!--Box Start-->
                        <div class="tab-content wf100" id="nav-tabContent">
                            <div class="tab-pane fade" id="nav-defenders" role="tabpanel"
                                aria-labelledby="nav-1-tab">
                                <div class="accordion" id="accordionExample">
                                    <?php $liveIds = []; ?>

                                    <?php if($matches): ?>
                                        <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">
                                                <div class="item-header" id="<?= $key ?>">
                                                    <h2 class="mb-20">
                                                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                                            data-target="#collapseOne<?= $key ?>" aria-expanded="true"
                                                            aria-controls="collapseOne<?= $key ?>">
                                                            <?php echo e($value['league']); ?>

                                                            <i class="fe-chevron-down"></i>
                                                        </button>
                                                    </h2>
                                                </div>

                                                <div id="collapseOne<?= $key ?>"
                                                    class="collapse <?php echo e($key == 0 ? 'show' : ''); ?>"
                                                    aria-labelledby="headingOne<?= $key ?>"
                                                    data-parent="#accordionExample">
                                                    <?php $__currentLoopData = $value['matches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php array_push($liveIds, $match['fixtureId']); ?>
                                                        <div class="last-match-result-full-light"
                                                            onclick="redirectToURL('<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>')">
                                                            <div class="row">
                                                                <div class="col-5 no-padding">
                                                                    <div class="match-left">
                                                                        <div class="mtl-left"> <img
                                                                                src="<?php echo e($match['homeTeamLogo']); ?>"
                                                                                >
                                                                            <strong><a class="color-bcc9ea"
                                                                                    href="<?php echo e(route('teams.matches', [$match['homeTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['homeTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['homeTeamName']); ?></a></strong>
                                                                        </div>
                                                                        <div class="mscore float-right">
                                                                            <strong><?php echo e($match['homeTeamGoal']); ?></strong>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="col-2 no-padding">
                                                                    <div class="lmr-info">
                                                                        <strong class="color-font-6ed950-15"><?php echo e($match['elapsed'] . '"'); ?></strong>
                                                                        <a href="<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>" class="mh padding-0-5"><?php echo e(in_array($match['fixtureId'], $matchArray) && in_array($match['shortStatus'], $liveStatus) ? __('Watch Live') : __('Live')); ?></a>
                                                                    </div>
                                                                </div>
                                                                <div class="col-5 no-padding">
                                                                    <div class="match-right">
                                                                        <div class="mscore">
                                                                            <strong><?php echo e($match['awayTeamGoal']); ?></strong>
                                                                        </div>
                                                                        <div class="mtl-right"> <img
                                                                                src="<?php echo e($match['awayTeamLogo']); ?>"
                                                                                >
                                                                            <strong><a class="color-bcc9ea"
                                                                                    href="<?php echo e(route('teams.matches', [$match['awayTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['awayTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['awayTeamName']); ?></a></strong>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <h3 class="align-color-font">
                                            <?php echo e(__('Live Match Not Available')); ?></h3>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="tab-pane fade show active" id="nav-gk" role="tabpanel" aria-labelledby="nav-2-tab">
                                <div class="accordion" id="accordionExample">

                                    <?php if($fixtures): ?>
                                        <?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">
                                                <div class="item-header" id="<?= $sl ?>">
                                                    <h2 class="mb-20">
                                                        <button class="btn btn-link" type="button"
                                                            data-toggle="collapse" data-target="#collapseOne<?= $sl ?>"
                                                            aria-expanded="true" aria-controls="collapseOne<?= $sl ?>">
                                                            <?php echo e($value['league']); ?>

                                                            <i class="fe-chevron-down"></i>
                                                        </button>
                                                    </h2>
                                                </div>

                                                <div id="collapseOne<?= $sl ?>"
                                                    class="collapse <?php echo e($sl == 100 ? 'show' : ''); ?>"
                                                    aria-labelledby="headingOne<?= $sl ?>"
                                                    data-parent="#accordionExample">
                                                    <?php $__currentLoopData = $value['matches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="last-match-result-full-light"
                                                            onclick="redirectToURL('<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>')">
                                                            <div class="row">
                                                                <div class="col-5 no-padding">
                                                                    <div class="match-left">
                                                                        <div class="mtl-left"> <img
                                                                                src="<?php echo e($match['homeTeamLogo']); ?>"
                                                                                >
                                                                            <strong><a class="color-bcc9ea"
                                                                                    href="<?php echo e(route('teams.matches', [$match['homeTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['homeTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['homeTeamName']); ?></a></strong>
                                                                        </div>
                                                                        <?php if(!in_array($match['shortStatus'], $statusArray)): ?>
                                                                            <div class="mscore float-right">
                                                                                <strong><?php echo e($match['homeTeamGoal']); ?></strong>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-2 no-padding">
                                                                    <div class="lmr-info">
                                                                        <?php if($match['shortStatus'] === 'NS'): ?>
                                                                            <strong class="color-14844d">
                                                                                <?php echo e(date('d/m h:i A', $match['date'])); ?>

                                                                            </strong>
                                                                        <?php else: ?>
                                                                            <strong class="color-007399"><?php echo e($match['longStatus']); ?></strong>
                                                                        <?php endif; ?>
                                                                        
                                                                        <a href="<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>"
                                                                            class="mh padding-0-5">

                                                                            <?php echo e($match['shortStatus'] === 'NS' 
                                                                                ? __('Not Start') 

                                                                                : (in_array($match['fixtureId'], $matchArray) && in_array($match['shortStatus'], $liveStatus) 

                                                                                    ? __('Watch Live') 

                                                                                    : (in_array($match['shortStatus'], $liveStatus) 

                                                                                        ? __('Live') 

                                                                                        : __('Detail')))); ?>

                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="col-5 no-padding">
                                                                    <div class="match-right">
                                                                        <?php if(!in_array($match['shortStatus'], $statusArray)): ?>
                                                                        <div class="mscore">
                                                                            <strong><?php echo e($match['awayTeamGoal']); ?></strong>
                                                                        </div>
                                                                        <?php endif; ?>
                                                                        <div class="mtl-right"> <img
                                                                                src="<?php echo e($match['awayTeamLogo']); ?>"
                                                                                >
                                                                            <strong><a class="color-bcc9ea"
                                                                                    href="<?php echo e(route('teams.matches', [$match['awayTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['awayTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['awayTeamName']); ?></a></strong>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <?php
                                                $sl++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <!--Box End-->
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-3 col-md-3">
                        <div class="point-table-widget mb-10">
                            <table>
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('Teams')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [49, 'chelsea'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/49.png" 
                                                 class="img-class">
                                                <strong class="text-align">Chelsea,
                                                    England</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [33, 'manchester-united'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/33.png" 
                                                 class="img-class">
                                                <strong class="text-align">Manchester United,
                                                    England</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [529, 'Barcelona'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/529.png"
                                                     class="img-class">
                                                <strong class="text-align">Barcelona,
                                                    Spain</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [541, 'real-madrid'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/541.png"
                                                     class="img-class">
                                                <strong class="text-align">Real Madrid,
                                                    Spain</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [40, 'liverpool'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/40.png" 
                                                 class="img-class">
                                                <strong class="text-align">Liverpool,
                                                    England</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [42, 'Arsenal'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/42.png" 
                                                 class="img-class">
                                                <strong class="text-align">Arsenal,
                                                    England</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [50, 'manchester-city'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/50.png" 
                                                 class="img-class">
                                                <strong class="text-align">Manchester City,
                                                    England</strong></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="<?php echo e(route('teams.matches', [47, 'tottenham'])); ?>"><img
                                                    src="https://media.api-sports.io/football/teams/47.png" 
                                                 class="img-class">
                                                <strong class="text-align">Tottenham,
                                                    England</strong></a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="text-center"><a href="<?php echo e(route('teams')); ?>">
                                                <strong>View All</strong></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--widget start-->
                        <div class="featured-video-widget">
                            
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="fvideo-box mb15">
                                    <div class="fvid-cap">
                                        <h5><a target="_blank" href="<?php echo e($item->link); ?>"><?php echo e($item->title); ?></a>
                                        </h5>
                                    </div>
                                    <img src="https://img.youtube.com/vi/<?= $item->link ?>/1.jpg" >
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Sports Widgets End-->
    </div>
    <!--Main Content End-->

    <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('public\assets\front\js\home.min.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/front/home.blade.php ENDPATH**/ ?>