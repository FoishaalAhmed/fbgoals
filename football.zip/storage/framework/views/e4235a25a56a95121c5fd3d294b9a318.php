

<?php $__env->startSection('title', __('Live Matches')); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front/css/livescore.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!--Main Content Start-->
    <div class="main-content innerpagebg wf100">
        <!--team Page Start-->
        <div class="team wf100 p40">
            <!--Start-->
            <div class="player-squad">
                <div class="container">

                    <div class="row">
                        <!--Fixture Start-->
                        <div class="col-lg-8">
                            <div class="container">

                                <div class="accordion" id="accordionExample">
                                    <?php
                                        $liveStatus = ['1H', 'HT', '2H', 'ET', 'BT', 'P', 'INT', 'LIVE'];
                                    ?>

                                    <?php if($matches): ?>
                                        <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">

                                                <div class="item-header" id="<?= $key ?>">
                                                    <h2 class="mb-20">
                                                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                                            data-target="#collapseOne<?= $key ?>" aria-expanded="true"
                                                            aria-controls="collapseOne<?= $key ?>">
                                                            <?php echo e($value['league']); ?>

                                                            <i class="fe-chevron-down"></i>
                                                        </button>
                                                    </h2>
                                                </div>

                                                <div id="collapseOne<?= $key ?>"
                                                    class="collapse <?php echo e(in_array($value['leagueid'], $fixedLeagues) ? 'show' : ''); ?>"
                                                    aria-labelledby="headingOne<?= $key ?>" data-parent="#accordionExample">
                                                    <?php $__currentLoopData = $value['matches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="last-match-result-full-light" onclick="redirectToURL('<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>')">
                                                            <div class="row">
                                                                <div class="col-5 no-padding">
                                                                    <div class="match-left">
                                                                        <div class="mtl-left"> <img
                                                                                src="<?php echo e($match['homeTeamLogo']); ?>"
                                                                                alt="">
                                                                            <strong><a class="color-bcc9ea"
                                                                                    href="<?php echo e(route('teams.matches', [$match['homeTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['homeTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['homeTeamName']); ?></a></strong>
                                                                        </div>
                                                                        <div class="mscore float-right">
                                                                            <strong><?php echo e($match['homeTeamGoal']); ?></strong>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="col-2 no-padding">
                                                                    <div class="lmr-info">
                                                                        <strong
                                                                            class="color-6ed950-font-15"><?php echo e($match['elapsed'] . '"'); ?></strong>
                                                                        <a href="<?php echo e(route('match.detail', [$match['fixtureId'], str_replace(' ', '-', strtolower($match['homeTeamName'] . ' vs ' . $match['awayTeamName']))])); ?>"
                                                                            class="mh"><?php echo e(in_array($match['fixtureId'], $matchArray) && in_array($match['shortStatus'], $liveStatus) ? __('Watch Live') : __('Live')); ?></a>
                                                                    </div>
                                                                </div>
                                                                <div class="col-5 no-padding">
                                                                    <div class="match-right">
                                                                        <div class="mscore">
                                                                            <strong><?php echo e($match['awayTeamGoal']); ?></strong>
                                                                        </div>
                                                                        <div class="mtl-right"> <img
                                                                                src="<?php echo e($match['awayTeamLogo']); ?>"
                                                                                alt="">
                                                                            <strong><a class="color-bcc9ea" href="<?php echo e(route('teams.matches', [$match['awayTeamId'], str_replace([' ', '_', "'", '&'], '-', strtolower($match['awayTeamName'])), 'league' => $match['leagueId']])); ?>"><?php echo e($match['awayTeamName']); ?></a></strong>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                        <!--Fixture End-->
                        <!--Sidebar Start-->
                        <div class="col-lg-4">
                            <div class="sidebar mb-10">
                                <!--widget start-->
                                <?php echo $__env->make('front.upcomingMatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <!--widget end-->
                            </div>
                            <?php if($news->isNotEmpty()): ?>
                                <div class="h3-section-title"> <strong><?php echo e(__('Trending News')); ?></strong></div>
                                <div class="trending-news">
                                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!--Expand-->
                                        <div class="list-box-expand <?= $key == 0 ? 'active' : '' ?>">
                                            <div class="news-caption">
                                                <div class="news-txt">
                                                    <h4><a
                                                            href="<?php echo e(route('news.detail', [$item->id, str_replace([' ', '_', '&'], '-', strtolower($item->title))])); ?>"><?php echo e($item->title); ?></a>
                                                    </h4>
                                                    <ul class="news-meta">
                                                        <li><i class="fe-calendar"></i>
                                                            <?php echo e(date('D M, Y', strtotime($item->date))); ?></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="expand-news-img"><img
                                                    src="<?php echo e(file_exists($item->photo) ? asset($item->photo) : asset('public/images/news.jpg')); ?>"
                                                    alt=""></div>
                                        </div>
                                        <!--Expand-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <?php if($videos->isNotEmpty()): ?>
                                <div class="sidebar">
                                    <!--widget start-->
                                    <div class="widget">
                                        <h4><?php echo e(__('Featured Videos')); ?> </h4>
                                        <div class="featured-video-widget">
                                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="fvideo-box mb15">
                                                    <div class="fvid-cap">
                                                        <h5><a
                                                                href="https://www.youtube.com/watch?v=<?= $item->link ?>"><?php echo e($item->title); ?></a>
                                                        </h5>
                                                        <span><i class="fe-clock"></i>
                                                            <?php echo e(date('d M, Y', strtotime($item->date))); ?> </span>
                                                    </div>
                                                    <img src="https://img.youtube.com/vi/<?= $item->link ?>/1.jpg"
                                                        alt="">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <!--widget end-->
                                </div>
                            <?php endif; ?>
                        </div>
                        <!--Sidebar End-->
                    </div>
                </div>
            </div>
            <!--End-->
        </div>
        <!--team Page End-->
    </div>
    <!--Main Content End-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function redirectToURL(url) {
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\football\resources\views/front/livescore.blade.php ENDPATH**/ ?>